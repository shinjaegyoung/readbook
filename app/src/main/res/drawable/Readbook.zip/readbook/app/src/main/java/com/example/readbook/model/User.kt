package com.example.readbook.model


    data class User(
        val email: String? = null,
        val name: String? = null,
        val profileImageUrl: String? = null,
        val uid: String? = null
    )


