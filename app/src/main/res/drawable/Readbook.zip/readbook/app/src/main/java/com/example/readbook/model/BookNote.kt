package com.example.readbook.model

data class BookNote(

    val booktitle:String? = null,
    val bookcontent :String?=null

)
